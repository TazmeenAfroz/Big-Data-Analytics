#!/usr/bin/env python3
import sys

for line in sys.stdin:
    data = line.strip().split(",")
    if len(data) < 1:  # Skip empty lines
        continue

    key = data[0]
    value = 1
    print(f"{key}\t{value}")

