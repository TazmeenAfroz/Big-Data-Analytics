#!/usr/bin/env python3
import sys

total = 0
oldkey = None

for line in sys.stdin:
    data = line.strip().split("\t")

    if len(data) != 2:  # Skip lines that don't have exactly two parts
        continue

    thiskey, value = data

    try:
        value = int(value)  # Convert value to integer
    except ValueError:
        continue  # Skip lines where value is not a number

    if thiskey != oldkey and oldkey is not None:
        print(f"{oldkey}\t{total}")
        total = 0

    oldkey = thiskey
    total += value

# Print last key
if oldkey is not None:
    print(f"{oldkey}\t{total}")

