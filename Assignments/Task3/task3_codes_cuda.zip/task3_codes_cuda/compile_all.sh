#!/bin/bash

# Compile and run all CUDA files
for i in {1..11}; do
    echo "Compiling and running q${i}.c..."
    nvcc q${i}.cu -o q${i}
    ./q${i}
    echo ""
done
